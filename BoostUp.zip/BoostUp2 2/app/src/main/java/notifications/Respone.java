package notifications;

public class Respone {
    String success;
}
