package com.example.boostup;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Influencer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_influencer);
    }
}
